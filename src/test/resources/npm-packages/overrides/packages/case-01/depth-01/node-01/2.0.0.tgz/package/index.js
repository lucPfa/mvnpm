module.exports = {"name": "@mvnpm-fixture/case-01-d01-n01", "version": "2.0.0"};
