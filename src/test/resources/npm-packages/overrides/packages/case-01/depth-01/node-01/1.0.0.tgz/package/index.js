module.exports = {"name": "@mvnpm-fixture/case-01-d01-n01", "version": "1.0.0"};
