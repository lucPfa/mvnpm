module.exports = {"name": "@mvnpm-fixture/case-13-parent", "version": "1.0.0"};
