module.exports = {"name": "@mvnpm-fixture/case-13-child", "version": "2.0.0"};
