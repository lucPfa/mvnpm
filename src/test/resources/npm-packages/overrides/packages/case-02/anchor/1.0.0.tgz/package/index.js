module.exports = {"name": "@mvnpm-fixture/case-02-anchor", "version": "1.0.0"};
