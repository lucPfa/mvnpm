module.exports = {"name": "@mvnpm-fixture/case-02-d02-n01", "version": "2.0.0"};
