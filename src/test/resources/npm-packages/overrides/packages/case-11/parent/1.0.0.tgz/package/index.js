module.exports = {"name": "@mvnpm-fixture/case-11-parent", "version": "1.0.0"};
