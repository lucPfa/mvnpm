module.exports = {"name": "@mvnpm-fixture/case-11-child", "version": "2.0.0"};
