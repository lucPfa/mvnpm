module.exports = {"name": "@mvnpm-fixture/case-11-child", "version": "1.0.0"};
