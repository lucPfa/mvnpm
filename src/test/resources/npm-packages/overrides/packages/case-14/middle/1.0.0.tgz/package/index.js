module.exports = {"name": "@mvnpm-fixture/case-14-middle", "version": "1.0.0"};
