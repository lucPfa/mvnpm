module.exports = {"name": "@mvnpm-fixture/case-14-a", "version": "1.0.0"};
