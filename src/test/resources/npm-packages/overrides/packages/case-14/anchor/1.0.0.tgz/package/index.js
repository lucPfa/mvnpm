module.exports = {"name": "@mvnpm-fixture/case-14-anchor", "version": "1.0.0"};
