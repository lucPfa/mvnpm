module.exports = {"name": "@mvnpm-fixture/case-03-anchor", "version": "1.0.0"};
