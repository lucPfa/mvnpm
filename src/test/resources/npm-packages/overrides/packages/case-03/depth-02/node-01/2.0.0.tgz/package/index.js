module.exports = {"name": "@mvnpm-fixture/case-03-d02-n01", "version": "2.0.0"};
