module.exports = {"name": "@mvnpm-fixture/case-03-d02-n02", "version": "1.0.0"};
