module.exports = {"name": "@mvnpm-fixture/case-05-d10-n01", "version": "1.0.0"};
