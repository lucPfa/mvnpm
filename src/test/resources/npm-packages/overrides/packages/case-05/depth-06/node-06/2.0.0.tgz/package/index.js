module.exports = {"name": "@mvnpm-fixture/case-05-d06-n06", "version": "2.0.0"};
