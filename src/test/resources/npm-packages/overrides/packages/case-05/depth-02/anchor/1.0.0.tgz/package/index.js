module.exports = {"name": "@mvnpm-fixture/case-05-anchor-d02", "version": "1.0.0"};
