module.exports = {"name": "@mvnpm-fixture/case-05-d02-n02", "version": "1.0.0"};
