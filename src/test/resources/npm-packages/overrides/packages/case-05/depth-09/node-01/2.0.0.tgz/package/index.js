module.exports = {"name": "@mvnpm-fixture/case-05-d09-n01", "version": "2.0.0"};
