module.exports = {"name": "@mvnpm-fixture/case-05-d09-n08", "version": "1.0.0"};
