module.exports = {"name": "@mvnpm-fixture/case-05-d09-n09", "version": "2.0.0"};
