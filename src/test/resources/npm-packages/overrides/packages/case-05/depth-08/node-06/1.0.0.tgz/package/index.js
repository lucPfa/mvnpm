module.exports = {"name": "@mvnpm-fixture/case-05-d08-n06", "version": "1.0.0"};
