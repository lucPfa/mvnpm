module.exports = {"name": "@mvnpm-fixture/case-05-d08-n07", "version": "1.0.0"};
