module.exports = {"name": "@mvnpm-fixture/case-05-d08-n04", "version": "1.0.0"};
