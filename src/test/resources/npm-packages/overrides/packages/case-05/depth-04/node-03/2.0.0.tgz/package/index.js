module.exports = {"name": "@mvnpm-fixture/case-05-d04-n03", "version": "2.0.0"};
