module.exports = {"name": "@mvnpm-fixture/case-05-d04-n04", "version": "1.0.0"};
