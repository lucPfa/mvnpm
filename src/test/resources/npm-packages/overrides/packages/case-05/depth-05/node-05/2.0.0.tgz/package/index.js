module.exports = {"name": "@mvnpm-fixture/case-05-d05-n05", "version": "2.0.0"};
