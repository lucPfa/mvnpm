module.exports = {"name": "@mvnpm-fixture/case-05-anchor-d05", "version": "1.0.0"};
