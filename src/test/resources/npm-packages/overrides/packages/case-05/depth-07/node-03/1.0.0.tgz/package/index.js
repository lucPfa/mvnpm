module.exports = {"name": "@mvnpm-fixture/case-05-d07-n03", "version": "1.0.0"};
