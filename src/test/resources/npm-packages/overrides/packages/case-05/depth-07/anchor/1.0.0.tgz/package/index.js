module.exports = {"name": "@mvnpm-fixture/case-05-anchor-d07", "version": "1.0.0"};
