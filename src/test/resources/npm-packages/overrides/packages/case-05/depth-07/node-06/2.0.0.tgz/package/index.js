module.exports = {"name": "@mvnpm-fixture/case-05-d07-n06", "version": "2.0.0"};
