module.exports = {"name": "@mvnpm-fixture/case-05-d03-n02", "version": "1.0.0"};
