module.exports = {"name": "@mvnpm-fixture/case-07-b", "version": "1.0.0"};
