module.exports = {"name": "@mvnpm-fixture/case-07-anchor", "version": "1.0.0"};
