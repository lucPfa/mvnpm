module.exports = {"name": "@mvnpm-fixture/case-07-a", "version": "1.0.0"};
