module.exports = {"name": "@mvnpm-fixture/case-15-a", "version": "1.0.0"};
