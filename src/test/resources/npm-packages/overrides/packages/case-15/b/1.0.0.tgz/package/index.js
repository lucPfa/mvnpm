module.exports = {"name": "@mvnpm-fixture/case-15-b", "version": "1.0.0"};
