module.exports = {"name": "@mvnpm-fixture/case-15-anchor", "version": "1.0.0"};
