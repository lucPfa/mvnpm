module.exports = {"name": "@mvnpm-fixture/case-09-anchor", "version": "2.0.0"};
