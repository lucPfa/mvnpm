module.exports = {"name": "@mvnpm-fixture/case-10-anchor", "version": "1.0.0"};
