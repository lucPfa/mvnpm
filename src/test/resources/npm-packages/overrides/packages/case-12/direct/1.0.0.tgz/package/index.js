module.exports = {"name": "@mvnpm-fixture/case-12-direct", "version": "1.0.0"};
