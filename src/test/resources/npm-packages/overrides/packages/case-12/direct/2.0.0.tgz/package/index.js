module.exports = {"name": "@mvnpm-fixture/case-12-direct", "version": "2.0.0"};
