module.exports = {"name": "@mvnpm-fixture/case-04-anchor", "version": "1.0.0"};
