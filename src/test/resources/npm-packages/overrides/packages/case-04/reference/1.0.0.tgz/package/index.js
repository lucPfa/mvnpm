module.exports = {"name": "@mvnpm-fixture/case-04-reference", "version": "1.0.0"};
