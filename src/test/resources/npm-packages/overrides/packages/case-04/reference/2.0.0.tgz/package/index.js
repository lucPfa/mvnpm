module.exports = {"name": "@mvnpm-fixture/case-04-reference", "version": "2.0.0"};
