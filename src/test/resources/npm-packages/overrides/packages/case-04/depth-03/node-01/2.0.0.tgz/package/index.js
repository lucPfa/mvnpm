module.exports = {"name": "@mvnpm-fixture/case-04-d03-n01", "version": "2.0.0"};
