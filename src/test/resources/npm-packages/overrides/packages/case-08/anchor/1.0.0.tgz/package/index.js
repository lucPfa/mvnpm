module.exports = {"name": "@mvnpm-fixture/case-08-anchor", "version": "1.0.0"};
