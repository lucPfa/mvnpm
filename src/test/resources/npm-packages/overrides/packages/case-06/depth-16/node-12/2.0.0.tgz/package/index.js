module.exports = {"name": "@mvnpm-fixture/case-06-d16-n12", "version": "2.0.0"};
