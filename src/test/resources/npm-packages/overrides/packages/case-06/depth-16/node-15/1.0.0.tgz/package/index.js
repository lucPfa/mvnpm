module.exports = {"name": "@mvnpm-fixture/case-06-d16-n15", "version": "1.0.0"};
