module.exports = {"name": "@mvnpm-fixture/case-06-d16-n14", "version": "1.0.0"};
