module.exports = {"name": "@mvnpm-fixture/case-06-anchor-d16", "version": "1.0.0"};
