module.exports = {"name": "@mvnpm-fixture/case-06-d16-n09", "version": "1.0.0"};
