module.exports = {"name": "@mvnpm-fixture/case-06-d16-n08", "version": "2.0.0"};
