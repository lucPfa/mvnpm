module.exports = {"name": "@mvnpm-fixture/case-06-d16-n13", "version": "1.0.0"};
