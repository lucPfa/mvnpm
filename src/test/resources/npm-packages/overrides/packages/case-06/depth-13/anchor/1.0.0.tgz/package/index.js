module.exports = {"name": "@mvnpm-fixture/case-06-anchor-d13", "version": "1.0.0"};
