module.exports = {"name": "@mvnpm-fixture/case-06-d13-n04", "version": "2.0.0"};
