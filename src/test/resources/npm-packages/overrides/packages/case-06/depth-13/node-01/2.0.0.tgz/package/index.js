module.exports = {"name": "@mvnpm-fixture/case-06-d13-n01", "version": "2.0.0"};
