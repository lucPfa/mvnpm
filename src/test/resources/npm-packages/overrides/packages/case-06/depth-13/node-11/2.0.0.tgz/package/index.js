module.exports = {"name": "@mvnpm-fixture/case-06-d13-n11", "version": "2.0.0"};
