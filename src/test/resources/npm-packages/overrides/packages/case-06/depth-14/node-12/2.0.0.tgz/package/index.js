module.exports = {"name": "@mvnpm-fixture/case-06-d14-n12", "version": "2.0.0"};
