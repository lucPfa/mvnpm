module.exports = {"name": "@mvnpm-fixture/case-06-d14-n09", "version": "1.0.0"};
