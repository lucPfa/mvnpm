module.exports = {"name": "@mvnpm-fixture/case-06-d10-n10", "version": "1.0.0"};
