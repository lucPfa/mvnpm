module.exports = {"name": "@mvnpm-fixture/case-06-d10-n08", "version": "1.0.0"};
