module.exports = {"name": "@mvnpm-fixture/case-06-d10-n07", "version": "2.0.0"};
