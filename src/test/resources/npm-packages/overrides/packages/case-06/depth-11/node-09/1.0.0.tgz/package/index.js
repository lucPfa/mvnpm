module.exports = {"name": "@mvnpm-fixture/case-06-d11-n09", "version": "1.0.0"};
