module.exports = {"name": "@mvnpm-fixture/case-06-d11-n06", "version": "1.0.0"};
