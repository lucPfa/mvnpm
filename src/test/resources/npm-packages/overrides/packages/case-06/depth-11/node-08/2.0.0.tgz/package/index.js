module.exports = {"name": "@mvnpm-fixture/case-06-d11-n08", "version": "2.0.0"};
