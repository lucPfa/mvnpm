module.exports = {"name": "@mvnpm-fixture/case-06-d11-n02", "version": "2.0.0"};
