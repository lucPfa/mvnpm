module.exports = {"name": "@mvnpm-fixture/case-06-d11-n11", "version": "1.0.0"};
