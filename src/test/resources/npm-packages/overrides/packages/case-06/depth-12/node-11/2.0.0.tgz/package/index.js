module.exports = {"name": "@mvnpm-fixture/case-06-d12-n11", "version": "2.0.0"};
