module.exports = {"name": "@mvnpm-fixture/case-06-d12-n07", "version": "1.0.0"};
