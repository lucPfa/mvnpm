module.exports = {"name": "@mvnpm-fixture/case-06-d12-n08", "version": "1.0.0"};
