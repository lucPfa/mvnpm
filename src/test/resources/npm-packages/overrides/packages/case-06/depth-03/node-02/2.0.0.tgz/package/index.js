module.exports = {"name": "@mvnpm-fixture/case-06-d03-n02", "version": "2.0.0"};
