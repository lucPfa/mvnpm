module.exports = {"name": "@mvnpm-fixture/case-06-d03-n03", "version": "2.0.0"};
