module.exports = {"name": "@mvnpm-fixture/case-06-anchor-d03", "version": "1.0.0"};
