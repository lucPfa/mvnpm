module.exports = {"name": "@mvnpm-fixture/case-06-d06-n06", "version": "2.0.0"};
