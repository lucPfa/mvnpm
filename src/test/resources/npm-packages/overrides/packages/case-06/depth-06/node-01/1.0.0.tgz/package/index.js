module.exports = {"name": "@mvnpm-fixture/case-06-d06-n01", "version": "1.0.0"};
