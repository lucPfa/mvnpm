module.exports = {"name": "@mvnpm-fixture/case-06-d15-n12", "version": "2.0.0"};
