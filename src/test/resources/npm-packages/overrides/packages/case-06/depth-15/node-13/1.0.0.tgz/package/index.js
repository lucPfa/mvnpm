module.exports = {"name": "@mvnpm-fixture/case-06-d15-n13", "version": "1.0.0"};
