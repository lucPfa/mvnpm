module.exports = {"name": "@mvnpm-fixture/case-06-d15-n08", "version": "1.0.0"};
