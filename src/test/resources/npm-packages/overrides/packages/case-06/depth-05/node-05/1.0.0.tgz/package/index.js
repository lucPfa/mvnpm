module.exports = {"name": "@mvnpm-fixture/case-06-d05-n05", "version": "1.0.0"};
