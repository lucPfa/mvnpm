module.exports = {"name": "@mvnpm-fixture/case-06-anchor-d07", "version": "1.0.0"};
