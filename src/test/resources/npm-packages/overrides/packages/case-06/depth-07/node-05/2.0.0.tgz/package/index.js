module.exports = {"name": "@mvnpm-fixture/case-06-d07-n05", "version": "2.0.0"};
