module.exports = {"name": "@mvnpm-fixture/case-06-d07-n06", "version": "2.0.0"};
