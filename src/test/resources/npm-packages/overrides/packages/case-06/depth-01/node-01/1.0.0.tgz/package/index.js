module.exports = {"name": "@mvnpm-fixture/case-06-d01-n01", "version": "1.0.0"};
