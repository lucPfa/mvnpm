module.exports = {"name": "@mvnpm-fixture/case-06-d04-n02", "version": "2.0.0"};
