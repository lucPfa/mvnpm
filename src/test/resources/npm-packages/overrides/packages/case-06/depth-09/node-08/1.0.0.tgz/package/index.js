module.exports = {"name": "@mvnpm-fixture/case-06-d09-n08", "version": "1.0.0"};
