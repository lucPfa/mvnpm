module.exports = {"name": "@mvnpm-fixture/case-06-d09-n09", "version": "2.0.0"};
