module.exports = {"name": "@mvnpm-fixture/case-06-anchor-d09", "version": "1.0.0"};
