module.exports = {"name": "@mvnpm-fixture/case-06-d09-n02", "version": "1.0.0"};
