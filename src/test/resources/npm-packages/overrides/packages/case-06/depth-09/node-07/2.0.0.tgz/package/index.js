module.exports = {"name": "@mvnpm-fixture/case-06-d09-n07", "version": "2.0.0"};
